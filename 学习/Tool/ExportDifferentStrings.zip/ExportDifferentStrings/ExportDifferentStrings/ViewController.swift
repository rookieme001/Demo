//
//  ViewController.swift
//  ExportDifferentStrings
//
//  Created by whf on 7/24/19.
//  Copyright © 2019 rookieme. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        compareFile()
    }
    
    func compareFile() {
        let filePath1 = Bundle.main.path(forResource: "th", ofType: "txt")
        let filePath2 = Bundle.main.path(forResource: "en", ofType: "txt")
        let array1: Array? = readFile(path: filePath1!)
        let array2: Array? = readFile(path: filePath2!)
        
        var filteArrayArray: Array<String>? = Array()
        
        if let tempArray1 = array1 , let tempArray2 = array2 {
            for string1: String in tempArray2 {
                
                if !tempArray1.contains(string1) {
//                    filteArrayArray?.append(string1.replacingOccurrences(of: "\"", with: ""))
                    filteArrayArray?.append(string1)
                }
            }
            
            filterNotContainArray(path: filePath2!, filteArrayArray: filteArrayArray!)
        }
        
        
        
    }

    //读取文件
    func readFile(path: String) -> Array<String>? {
        do {
            let text2 = try String(contentsOfFile: path, encoding: .utf8)
            let tempText2 = text2.replacingOccurrences(of: "\n", with: "")
            let array: Array<String>  = tempText2.components(separatedBy: "\";")
            var tempArray: Array<String>? = Array()
            
           
            for string: String in array {
                
                let tempText2 = string.replacingOccurrences(of: "\" = \"", with: "\"=\"")

                let stringArray = tempText2.components(separatedBy: "\"=\"")

                if stringArray.count >= 2 && !string.contains("//") {
                    let tempString: String = stringArray[0]
                    tempArray?.append(tempString)
                }
            }

            return tempArray
        }
        catch {
            
        }
        
        return nil
    }
    

    func filterNotContainArray(path: String, filteArrayArray: Array<String>) {
        do {
            let text2 = try String(contentsOfFile: path, encoding: .utf8)
            let tempText2 = text2.replacingOccurrences(of: "\n", with: "")
            let array: Array<String>  = tempText2.components(separatedBy: "\";")
            
            
            for string: String in array {
                let tempText = string.replacingOccurrences(of: "\" = \"", with: "\"=\"")
                let stringArray = tempText.components(separatedBy: "\"=\"")
                if stringArray.count >= 2 && !string.contains("//") {
                    let tempString: String = stringArray[0]
                    
                    if filteArrayArray.contains(tempString) {
                        
                        print(string+"\"\n")
                        
                    }

                }
            }
            

        }
        catch {
            
        }
    }
}

