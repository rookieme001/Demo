//
//  ViewController.h
//  iOS-UDID-Safari
//
//  Created by Jakey on 2017/6/17.
//  Copyright © 2017年 Jakey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

