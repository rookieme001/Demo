//
//  LGStudent.m
//  LGTest
//
//  Created by cooci on 2019/4/8.
//

#import "LGStudent.h"

@implementation LGStudent

@end
