//
//  LGStudent.h
//  LGTest
//
//  Created by cooci on 2019/4/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGStudent : NSObject

@end

NS_ASSUME_NONNULL_END
